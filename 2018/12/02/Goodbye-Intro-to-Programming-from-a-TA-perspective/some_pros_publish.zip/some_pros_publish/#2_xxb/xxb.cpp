#include <bits/stdc++.h>

char str[10010];

int main(){
	while (gets(str+1))
		printf(" printf(%c%s%c%c%c);\n",'"',str+1,'\\','n','"');
	return 0;
}
