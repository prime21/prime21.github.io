#include<stdio.h>
#include<stdlib.h>
int cmp(const void* a, const void* b)
{
	return (*(int*)a-*(int*)b);
}
int max(int x,int y) { return x > y ? x : y; }

int n, i, a[1000010];
int main()
{
//	freopen("text.in","r",stdin); 
	scanf("%d", &n);
	for (i = 0; i < n; ++i)
		scanf("%d", &a[i]); 
	qsort(a, n, sizeof(int), cmp);
	int num = 1, ans = 0;
	for (i = 1; i < n; ++i) {
		if (a[i] == a[i - 1]) ++num;
		else num = 1;
		ans = max(ans, num);
	}
	printf("%d\n", ans);
	return 0;
}
