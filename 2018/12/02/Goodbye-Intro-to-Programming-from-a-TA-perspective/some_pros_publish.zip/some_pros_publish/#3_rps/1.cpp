#include <stdio.h>

char str[1010];

int main(){
	
	while (~scanf("%s",str))
	{
		if (str[0]=='r')
			printf("paper\n");
		else if (str[0]=='p')
			printf("scissors\n");
		else if (str[0]=='s')
			printf("rock\n");
	}

	return 0;
}
