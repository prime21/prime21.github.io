#include <stdio.h>
#include <stdlib.h>


int a[101010];
int n;

int cmp(const void *a,const void *b){
	return *((int *)a) - *( (int *)b);
}

void work(){
	int i;
	for (i=1;i<=n;i++)
		scanf("%d",a+i);
	qsort(a+1,n,sizeof(int),cmp);
	int d = a[2]-a[1];
	int flag=1;
	for (i=3;i<=n;i++)
		if (a[i]-a[i-1]!=d)
		{
			flag=0;
			break;
		}
	if (flag)
		printf("Yes");
	else
		printf("NO");
}

int main(){
	scanf("%d",&n);
	if (n==1 || n==2)
		printf("Yes\n");
	else 
		work();
	return 0;
}
