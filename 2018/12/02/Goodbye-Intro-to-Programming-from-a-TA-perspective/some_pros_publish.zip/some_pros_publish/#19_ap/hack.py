n = 100000
a = (list)(range(n))

for i in range(n):
    j = i // 2
    a[i], a[j] = a[j], a[i]

for i in range(n):
    print (a[i])
