#include <stdio.h>

long long n;
long long cnt=0;

int main(){
	scanf("%lld",&n);
	for (;n>4;cnt+=(n=n/5)); 
	printf("%lld\n",cnt);
	return 0;
}

