#include <bits/stdc++.h>

using namespace std;

#define REP(I,A,B) for (int I=(A),I##_END_=(B);I<=I##_END_;I++)
#define FOR(I,A,B) for (int I=(A),I##_END_=(B);I<I##_END_;I++)
#define REPD(I,A,B) for (int I=(A),I##_END_=(B);I>=I##_END_;I--)

char in[10];
char ou[10];
char cmd[100];

int yes[100];
int a[100];

int main(){
	srand(time(NULL));
	FOR(_,0,10)
	{
		sprintf(in,"%c.in",'a'+_);
		sprintf(ou,"%c.ans",'a'+_);
		memset(yes,0,sizeof yes);

		int sum=0;

		freopen(in,"w",stdout);
		REP(i,1,5)
		{
			int val;
			do
			{
				val=rand()%100+1;
			}while (yes[val]);
			a[i]=val;
			sum+=val;
			printf("%d ",val);
		}
		fclose(stdout);

		freopen(ou,"w",stdout);
		sort(a+1,a+5+1);
		printf("%d\n%.2lf\n",a[3],sum*1./5);
	}
	return 0;
}
