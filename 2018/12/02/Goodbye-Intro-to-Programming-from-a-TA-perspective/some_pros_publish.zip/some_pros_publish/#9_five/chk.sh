
./five < a.in > a.out
if diff a.out a.ans;
then
	echo "AC on a"
fi


./five < b.in > b.out
if diff b.out b.ans;
then
	echo "AC on b"
fi


./five < c.in > c.out
if diff c.out c.ans;
then
	echo "AC on c"
fi


./five < d.in > d.out
if diff d.out d.ans;
then
	echo "AC on d"
fi


./five < e.in > e.out
if diff e.out e.ans;
then
	echo "AC on e"
fi


./five < f.in > f.out
if diff f.out f.ans;
then
	echo "AC on f"
fi


./five < g.in > g.out
if diff g.out g.ans;
then
	echo "AC on g"
fi


./five < h.in > h.out
if diff h.out h.ans;
then
	echo "AC on h"
fi


./five < i.in > i.out
if diff i.out i.ans;
then
	echo "AC on i"
fi


./five < j.in > j.out
if diff j.out j.ans;
then
	echo "AC on j"
fi
