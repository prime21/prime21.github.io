#include <stdio.h>

#define calc(I) ( (I<=a) + (I<=b) + (I<=c) + (I<=d) + (I<=e) )

int main(){
	int a,b,c,d,e;
	int x;
	int sum=0;
	scanf("%d%d%d%d%d",&a,&b,&c,&d,&e);

	sum = a+b+c+d+e;

	if (calc(a) == 3 ) x = a;
	if (calc(b) == 3 ) x = b;
	if (calc(c) == 3 ) x = c;
	if (calc(d) == 3 ) x = d;
	if (calc(e) == 3 ) x = e;

	printf("%d\n%.2lf\n",x,sum*1./5);

	return 0;
}
