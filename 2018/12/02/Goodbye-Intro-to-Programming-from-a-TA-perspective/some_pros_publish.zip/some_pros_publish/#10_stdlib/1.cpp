#include <stdio.h>
#include <stdlib.h>

int main(){
	long long x=0;
	scanf("%lld",&x);
	printf("%lld\n",llabs(x));
	return 0;
}
