echo "a"
diff a.ans a.out

echo "b"
diff b.ans b.out

echo "c"
diff c.ans c.out

echo "d"
diff d.ans d.out

echo "e"
diff e.ans e.out

echo "f"
diff f.ans f.out

echo "g"
diff g.ans g.out

echo "h"
diff h.ans h.out
