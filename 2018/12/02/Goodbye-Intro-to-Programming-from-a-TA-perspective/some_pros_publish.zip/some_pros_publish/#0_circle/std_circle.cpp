#include <stdio.h>
#include <math.h>

using namespace std;

#define y1 yyyyyy
#define y0 jyyyyyy

const double eps = 1e-4;

double x1,x2,x3,y1,y2,y3;
double x0,y0;
double a,b,c,d,e,f;

int main(){
	scanf("%lf%lf",&x1,&y1);
	scanf("%lf%lf",&x2,&y2);
	scanf("%lf%lf",&x3,&y3);

	a = x1 - x2;
	b = y1 - y2;
	c = x1 - x3;
	d = y1 - y3;
	e = (x1*x1-x2*x2) - (y2*y2-y1*y1); e/=2;
	f = (x1*x1-x3*x3) - (y3*y3-y1*y1); f/=2;

	x0 = - ( d*e - b*f ) / ( b*c - a*d );
	y0 = - ( a*f - c*e ) / ( b*c - a*d );

	if (fabs(x0) < eps) x0=abs(x0);
	if (fabs(y0) < eps) y0=abs(y0);

	printf("(%.2lf,%.2lf)",x0,y0);

	return 0;
}
