#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define lowbit(X)  ((X)&(-X))

int n;
int S[1048576+100]; 
int L,R;

void output(int Sta){
	int i=0;
	for (i=n-1;i>=0;i--)
		if ((Sta>>i)&1)
			printf("%c ",n-1-i+'A');
	printf("\n");
}

int main(){
	int i,j;
	L=R=0;
	scanf("%d",&n);
	for (i=n-1;i>=0;i--)
		S[R++] = 1<<i;
	while (L<R)
	{
		output(S[L]);
		for ( j = lowbit(S[L])>>1 ; j ; j >>= 1 )
			S[R++] = S[L] | j;
		L++;
	}
	return 0;
}
