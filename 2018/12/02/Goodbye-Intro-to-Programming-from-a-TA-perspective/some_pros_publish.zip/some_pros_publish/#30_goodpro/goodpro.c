#include <stdio.h>
#include <string.h>

char name[4][20];
int p[4];
int q[4];

int o[4];

int main(){
	int i,j;
	int t;
	for (i=1;i<=3;i++) scanf("%s%d%d",name[i],p+i,q+i);

	for (i=1;i<=3;i++) o[i]=i;

	for (i=1;i<3;i++)
		for (j=i+1;j<=3;j++)
			if (p[ o[i] ]<p[ o[j] ] || ( p[ o[i] ] == p[ o[j] ]  && strcmp(name[o[i]], name[o[j]])>0 ) )
			{
				t = o[i];
				o[i] = o[j];
				o[j] = t;
			}

	for (i=1;i<=3;i++) 
		if (p[ o[i] ] == p[o[1]]) printf("%s ",name[o[i]]);
	printf("\n");

	for (i=1;i<3;i++)
		for (j=i+1;j<=3;j++)
			if (q[ o[i] ]<q[ o[j] ] || ( q[ o[i] ] == q[ o[j] ]  && strcmp(name[o[i]], name[o[j]])>0 ) )
			{
				t = o[i];
				o[i] = o[j];
				o[j] = t;
			}

	for (i=1;i<=3;i++) 
		if (q[ o[i] ] == q[o[1]]) printf("%s ",name[o[i]]);
	printf("\n");

	for (i=1;i<3;i++)
		for (j=i+1;j<=3;j++)
			if (p[ o[i] ] + q[ o[i] ] <p[ o[j] ] + q[ o[j] ] || ( p[ o[i] ] + q[o[i]] == p[ o[j] ]  + q[ o[j] ] && strcmp(name[o[i]], name[o[j]])>0 ) )
			{
				t = o[i];
				o[i] = o[j];
				o[j] = t;
			}

	for (i=1;i<=3;i++) 
		if (p[ o[i] ] + q[ o[i] ] == p[o[1]] + q[o[1]] ) printf("%s ",name[o[i]]);
	printf("\n");


	return 0;
}
