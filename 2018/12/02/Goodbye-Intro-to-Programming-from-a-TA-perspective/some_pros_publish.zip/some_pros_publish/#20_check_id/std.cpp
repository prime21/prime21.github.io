#include <stdio.h>

int vl[]={7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2};
char m[]={'1','0','X','9','8','7','6','5','4','3','2'};

char id[22];
int n;

int main(){
	int i=1,j;
	int sum=0;
	int flag=0;
	int ans_flag=1;
	scanf("%d",&n);
	for (i=1;i<=n;i++)
	{
		scanf("%s",id);
		sum=0;
		flag=1;

		for (j=0;j<=16;j++)
		if (id[j]>='0' && id[j]<='9')
			sum+= (id[j]-'0')*vl[j];
		else
			flag=0;

		sum%=11;
		if (m[sum]!=id[17])
			flag=0;

		if (flag==0)
		{
			ans_flag=0;
			printf("%s\n",id);
		}
	}
	if (ans_flag)
		printf("All passed");
	return 0;
}
