#include <stdio.h>

long long a,b,c,d;

int main(){
	scanf("%lld%lld%lld%lld",&a,&b,&c,&d);
	if ( a&(a-1) ) printf("No\n"); else printf("Yes\n");
	if ( b&(b-1) ) printf("No\n"); else printf("Yes\n");
	if ( c&(c-1) ) printf("No\n"); else printf("Yes\n");
	if ( d&(d-1) ) printf("No\n"); else printf("Yes\n");
	return 0;
}
