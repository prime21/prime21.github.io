#include <stdio.h>

int main(){
	int now,lim;
	double ratio;
	scanf("%d%d",&now,&lim);
	ratio = now *1. /lim * 100;
	if (ratio < 110)
		printf("OK");
	else
	{
		printf("Exceed %.0lf%c. ",ratio-100,'%');
		if (ratio<150)
			printf("Ticket 200");
		else
			printf("License Revoked");
	}
	return 0;
}
