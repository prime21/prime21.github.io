#include <stdio.h>
#include <cstring>

#define REP(I,A,B) for (int I=(A),I##_END_=(B);I<=I##_END_;I++)
#define FOR(I,A,B) for (int I=(A),I##_END_=(B);I<I##_END_;I++)
#define REPD(I,A,B) for (int I=(A),I##_END_=(B);I>=I##_END_;I--)

using namespace std;

int cnt[2][300];
char s[2][1010];

int main(){
	scanf("%s%s",s[0],s[1]);
	FOR(kd,0,2)
	FOR(i,0,strlen(s[kd])){
		cnt[kd][s[kd][i]]++;
	}
	bool flag=true;
	REP(i,0,255) flag&=cnt[0][i]==cnt[1][i];
	if (flag)
		printf("TAK\n");
	else
		printf("NIE\n");
	return 0;
}
