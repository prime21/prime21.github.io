#include <stdio.h>

int n;
int a[12];
int b[12];

int main(){
	int i,ans=0;
	scanf("%d",&n);
	for (i=1;i<=n;i++ ) scanf("%d",a+i);
	for (i=1;i<=n;i++ ) scanf("%d",b+i);
	for (i=1;i<=n;i++) ans+=a[i]*b[i];
	printf("%d\n",ans);
	return 0;
}
