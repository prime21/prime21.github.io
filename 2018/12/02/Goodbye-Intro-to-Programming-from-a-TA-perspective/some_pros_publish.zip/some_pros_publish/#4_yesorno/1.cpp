#include <algorithm>
#include <stdio.h>

using namespace std;

#define lowbit(x) ((x)&(-(x)))
#define REP(I,A,B) for (int I=(A),I##_END_=(B);I<=I##_END_;I++)
#define FOR(I,A,B) for (int I=(A),I##_END_=(B);I<I##_END_;I++)
#define REPD(I,A,B) for (int I=(A),I##_END_=(B);I>=I##_END_;I--)

int x[10]={0};

int v[10]={};

int N;

int ss[2020];

int check(int A,int B){
	int ret=0;
	FOR(i,0,N)
	{
		ret+=(A&1)==(B&1);
		A>>=1;
		B>>=1;
	}
	return ret;
}

void output(int s){
	REPD(i,N-1,0)
		printf("%d",(s>>i)&1);
	printf(" ");
}

void init(){
	int tmp;
	scanf("%d",&N);
	REP(i,1,N) { scanf("%d",&tmp); x[0]=(x[0]<<1)|tmp; } scanf("%d",v); v[0]/=10;
	REP(i,1,N) { scanf("%d",&tmp); x[1]=(x[1]<<1)|tmp; } scanf("%d",v+1); v[1]/=10;
	REP(i,1,N) { scanf("%d",&tmp); x[2]=(x[2]<<1)|tmp; } scanf("%d",v+2); v[2]/=10;
	REP(i,1,N) { scanf("%d",&tmp); x[3]=(x[3]<<1)|tmp; }
}

int main(){
	int ret=0;
	bool flag=false;

	init();

	int tot=0;
	FOR(s,0,1<<N)
	{
		flag=true;

		FOR(i,0,3)
			flag &= check(s,x[i]) == v[i];

		if (flag)
		{
			ret=check(s,x[3]);
			//output(s);
			//printf("%d0\n",ret);
			ss[++tot] = ret;
		}

	}

	/*
	output(x[0]); printf("%d0\n",v[0]);
	output(x[1]); printf("%d0\n",v[1]);
	output(x[2]); printf("%d0\n",v[2]);
	output(x[3]); printf("\n");
	*/

	sort ( ss+1,ss+1+tot);
	tot=unique(ss+1,ss+1+tot)-ss-1;
	REP(i,1,tot)
		printf("%d ",ss[i]*10);

	return 0;
}
