#include <stdio.h>
#include <stdlib.h>

int wz[10];

int main(){
	int i,j;
	for (i=0;i<=9;i++) scanf("%d",wz+i);
	if (wz[0]) {
		for (i=1;i<=9;i++)
			if (wz[i])
			{
				printf("%d",i);
				wz[i]--;
				break;
			}
	}
	for (i=0;i<=9;i++) for (j=1;j<=wz[i];j++)printf("%d",i);
	return 0;
}
