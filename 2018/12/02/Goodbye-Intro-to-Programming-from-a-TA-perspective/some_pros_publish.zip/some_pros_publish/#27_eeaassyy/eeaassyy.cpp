#include <stdio.h>

void fun(int *a,int *b){
	*a = *a + *b;
	*b = *a - *b;
}

int a,b,c,d;

int main(){
	scanf("%d%d%d%d",&a,&b,&c,&d);
	fun(&a,&b);
	fun(&c,&d);
	fun(&b,&c);
	printf("%d %d %d %d\n",a,b,c,d);
	printf("na=a+b\n");
	printf("nb=a+c+d\n");
	printf("nc=a\n");
	printf("nd=c\n");
	return 0;
}
