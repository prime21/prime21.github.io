#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int n,st,T;
int total;
int hole[101010];

int main(){
	int i;
	memset(hole,0,sizeof hole);
	scanf("%d%d%d",&n,&st,&T);
	hole[st]=1;
	for (i=2; i<=T ;i++)
	{
		st = (st+i-1)%n +1;
		hole[st]=1;
	}
	total=0;
	for (i=1;i<=n;i++) total += hole[i] == 0;
	if (total)
	{
		printf("%d\n",total);
		for (i=1;i<=n;i++)
			if (hole[i]==0) printf("%d ",i);
	}
	else
		printf("have a pokemon");
	return 0;
}
