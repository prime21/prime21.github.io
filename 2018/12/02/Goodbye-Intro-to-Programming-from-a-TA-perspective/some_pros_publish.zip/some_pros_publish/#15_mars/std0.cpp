#include <stdio.h>
#include <string.h>

char lo[][20]={ "tret","jan","feb","mar","apr","may","jun","jly","aug","sep","oct","nov","dec"};
char hi[][20]={"","tam","hel","maa","huh","tou","kes","hei","elo","syy","lok","mer","jou"};

char str[1000];
char tmp[1010];

void make_int(){
	int d;
	sscanf(str,"%d",&d);
	if (d/13) printf("%s%c",hi[d/13],(d%13)?' ':'\n');
	if ((d%13) || d==0)printf("%s\n",lo[d%13]);
}
void make_mars(){
	int len=strlen(str);
	int ret=0;
	int i;
	if (len<=4){
		sscanf(str,"%s",tmp);

		for (i=0;i<=12;i++)
			if (strcmp(tmp,lo[i])==0)
				ret+=i;

		for (i=1;i<=12;i++)
			if (strcmp(tmp,hi[i])==0)
				ret+=i*13;

	}
	else
	{

		sscanf(str,"%s",tmp);
		for (i=1;i<=12;i++)
			if (strcmp(tmp,hi[i])==0)
				ret+=i;
		ret*=13;

		sscanf(str+4,"%s",tmp);
		for (i=0;i<=12;i++)
			if (strcmp(tmp,lo[i])==0)
				ret+=i;

	}
	printf("%d\n",ret);
}

int main(){
	int n;
	int i;

	gets(str);
	//fgets(str,1000,stderr);
	if (str[0]>='0' && str[0]<='9')
		make_int();
	else
		make_mars();

	return 0;
}
