#include <stdio.h>

#define REP(I,A,B) for (int I=(A),I##_END_=(B);I<=I##_END_;I++)
#define FOR(I,A,B) for (int I=(A),I##_END_=(B);I<I##_END_;I++)
#define REPD(I,A,B) for (int I=(A),I##_END_=(B);I>=I##_END_;I--)

int main(){
	int _=0;
	int L,R;
	int ret=0;
	scanf("%d",&_);
	REP(__,1,_)
	{
		ret=0;
		scanf("%d%d",&L,&R);
		REP(i,L,R)
			ret+=(i%10==2) || (i%10==3) || (i%10==9);
		printf("%d\n",ret);
	}
	return 0;
}
