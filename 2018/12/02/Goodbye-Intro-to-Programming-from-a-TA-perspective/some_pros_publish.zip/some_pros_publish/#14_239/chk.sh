stdstd < a.in > output.txt
diff a.out output.txt

stdstd < b.in > output.txt
diff b.out output.txt

stdstd < c.in > output.txt
diff c.out output.txt

stdstd < d.in > output.txt
diff d.out output.txt

stdstd < e.in > output.txt
diff e.out output.txt

stdstd < f.in > output.txt
diff f.out output.txt

stdstd < g.in > output.txt
diff g.out output.txt

stdstd < h.in > output.txt
diff h.out output.txt

stdstd < i.in > output.txt
diff i.out output.txt

stdstd < j.in > output.txt
diff j.out output.txt
