#include <stdio.h>

int main(){
	long long L,R;
	long long ret=0;
	scanf("%lld%lld",&L,&R);

	ret+=(L%10)<=1;
	ret+=(L%10)<=8;
	ret+=(L%10)<=7;
	ret+=(L%10)<=3;
	L=L/10+1;

	ret+=(R%10)>=1;
	ret+=(R%10)>=8;
	ret+=(R%10)>=7;
	ret+=(R%10)>=3;
	R=R/10-1;

	if (L<=R) ret+= (R-L+1) * 4;

	printf("%lld\n",ret);

	return 0;
}
