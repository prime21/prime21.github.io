#include <stdio.h>

double now=1.;
double sum=0;

double x;
int m;

int main(){
	int i=0;
	scanf("%lf%d",&x,&m);
	for(i=0;i<=m;i++)
	{
		if (i&1) 
			sum-=now;
		else 
			sum+=now;
		now=now*x*x;
		now=now/((i+i+1)*(i+i+2));
	}
	printf("%.6lf\n",sum);
	return 0;
}

#include <stdio.h>
