#include <stdio.h>

long long a[1010];
long long A,B;

int main(){
	int n,i;
	A=B=0;
	scanf("%d",&n);
	for (i=1;i<=n;i++)
	{
		scanf("%lld",a+i);
		A+=a[i];
		B^=a[i];
	}
	A|=B;
	printf("%lld\n",A);
	return 0;
}
