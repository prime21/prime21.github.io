#include <stdio.h>

int main(){
	int _=0;
	int L,R;
	int i;
	int ret=0;
	scanf("%d%d",&L,&R);
	for (i=L;i<=R;i++)

		if ( ( i%10 == 1) + ( i%10 == 8)  + (i%10 == 7) + (i%10 == 3) )
			printf("%d\n",i);
	return 0;
}
