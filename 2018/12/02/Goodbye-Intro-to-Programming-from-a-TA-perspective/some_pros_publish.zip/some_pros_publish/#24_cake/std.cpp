#include <stdio.h>

int n;
int all;
int a[30];
long long ans;

int gcd(int a,int b){
	int t;
	while(b){
		t= a%b;
		a = b;
		b = t;
	}
	return a;
}

int main(){
	int i,j,ret,flag;
	scanf("%d",&n);
	all = (1<<n)-1;
	for (i=0;i<n;i++) scanf("%d",a+i);

	ans=0;
	for (i=0;i<=all;i++)
	{
		ret=flag=0;
		for (j=0;j<n;j++)
		if ((i>>j)&1)
		{
			ret=gcd(ret,a[j]);
			flag++;
		}

		if (flag&1)
			ans+=ret;
		else
			ans-=ret;
	}
	printf("%d\n",ans);

	return 0;
}
