#include <stdio.h>
#include <math.h>

double calc(double x){
	return 2 * sin(x)  + sin(2*x) + sin(3*x) + (x-1) *(x-1) ;
}

int main(){
	double l,r,mid;
	double y;
	while (~scanf("%lf",&y))
	{
		l = 4.0;
		r = 8.0;

		if ( y < calc(l) || y > calc(r) )
		{
			printf("No solution!\n");
			continue;
		}

		while (r-l>1e-8){
			mid = (l+r)/2;
			if (calc(mid)<y)
				l = mid;
			else 
				r = mid;
		}
		printf("%.6lf\n",l);
	}
	return 0;
}

