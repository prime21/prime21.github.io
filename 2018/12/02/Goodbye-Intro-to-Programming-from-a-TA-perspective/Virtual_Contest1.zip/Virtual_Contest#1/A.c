#include <stdio.h>

int n;
int a[101];
int b[101];
int i,ret=0;

int main(){
	scanf("%d",&n);
	for (i=1;i<=n;i++) scanf("%d",a+i);
	for (i=1;i<=n;i++) scanf("%d",b+i);
	for (i=1;i<=n;i++) ret+=a[i]*b[i];
	printf("%d",ret);
	return 0;
}
