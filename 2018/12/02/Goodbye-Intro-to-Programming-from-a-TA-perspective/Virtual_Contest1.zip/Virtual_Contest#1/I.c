#include <stdio.h>
#include <math.h>

long long N;
long long k;
long long d;
long long s;
long long i;

int check(long long p){
	return  ( p*(p+1)/2 < N ) && ( (p+1)*(p+2) / 2 >= N);
}

int main(){
	scanf("%lld",&N);

	k = ( long long ) sqrt( 2.0*N );
	for (i = k-3; i<=k+3 ; i++)
	if (check(i))
	{
		d = i+1 ;
		s = i *(i+1) /2;
		break;
	}

	if (d & 1)
		printf("%lld/%lld\n",d+1 - (N-s) , N-s );
	else
		printf("%lld/%lld\n", N-s , d+1 - (N-s));


	return 0;
}
