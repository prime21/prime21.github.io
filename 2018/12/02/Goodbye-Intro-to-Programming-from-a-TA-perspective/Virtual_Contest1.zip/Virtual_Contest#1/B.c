#include <stdio.h>

int n;
int i;

int main(){
	int a;
	scanf("%d",&n);
	for (i=1;i<=n;i++)
	{
		scanf("%d",&a);
		if ( a>=85 && a<=100 )
			printf("A\n");
		else if (a>=70)
			printf("B\n");
		else if (a>=60)
			printf("C\n");
		else if (a<60)
			printf("D\n");
	}
	return 0;
}
