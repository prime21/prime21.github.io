#include <stdio.h>

int n,w,h;

int M[111][111];

int main(){
	int i,j,k;
	int lx,ly,rx,ry,col;
	int t;
	scanf("%d%d%d",&n,&w,&h);

	for (i=0;i<h;i++) for (j=0;j<w;j++)
		M[i][j]=16777215;

	for (i=1;i<=n;i++)
	{
		scanf("%d%d%d%d%d",&lx,&ly,&rx,&ry,&col);
		if (lx>rx) {
			t = lx;
			lx = rx;
			rx = t;
		}
		if (ly>ry) {
			t = ly;
			ly = ry;
			ry = t;
		}

		for (j=ly;j<=ry;j++)
			for (k=lx;k<=rx;k++)
				M[j][k] = col;
	}
	for (i=0;i<h;i++) 
	{
		for (j=0;j<w;j++)
			printf("#%06X ",M[i][j]);
		printf("\n");
	}

	return 0;
}
