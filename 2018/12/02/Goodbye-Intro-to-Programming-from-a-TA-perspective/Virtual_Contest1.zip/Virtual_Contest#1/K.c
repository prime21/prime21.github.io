#include <stdio.h>
#include <string.h>

char str[10101];
int len;

int get_num(int l,int r){
	int i,ret=0;
	for (i=l;i<=r;i++)
		ret = ret*10+ str[i]-'0';
	return ret;
}

int is_num(int l,int r){
	int i;
	for (i=l;i<=r;i++)
		if (str[i]<'0' || str[i]>'9')
			return 0;
	return 1;
}

int is_sub(int l,int r){
	int i,in=0;
	if (str[l]!='(' || str[r]!=')') return 0;
	for (i=l;i<r;i++) {
		in+=str[i]=='(';
		in-=str[i]==')';
		if (in==0) return 0;
	}
	return 1;
}

int get_lst(int L,int R){
	int i,ret=-1;
	int in = 0;
	for (i=R;i>=L;i--)
	{
		in+=str[i]=='(';
		in-=str[i]==')';
		if (in !=0) continue;

		if (str[i] == '+' || str[i] == '-') return i;

		if ((str[i]=='*' || str[i]=='/') && ret==-1) ret = i;
	}
	return ret;
}

int calc(int L,int R){
	if (L>R) return 0;

	if (is_num(L,R)) return get_num(L,R);
	if (is_sub(L,R)) return calc(L+1,R-1);
	int mid = get_lst(L,R);

	if (str[mid]=='+')
		return calc(L,mid-1) + calc(mid+1,R);
	if (str[mid]=='-')
		return calc(L,mid-1) - calc(mid+1,R);
	if (str[mid]=='*')
		return calc(L,mid-1) * calc(mid+1,R);
	if (str[mid]=='/')
		return calc(L,mid-1) / calc(mid+1,R);
	return 0;
}

int main(){
	while (~scanf("%s",str+1)){
		len = strlen(str+1);
		printf("%d\n", calc(1,len));
	}
	return 0;
}
