#include <stdio.h>
#include <string.h>

char num[1010101];
int i,len;

int main(){
	int ret=0;
	scanf("%s",num);
	len = strlen(num);
	for (i=0;i<len;i++)
		ret+=num[i]-'0';
	printf("%d\n",ret);
	return 0;
}
