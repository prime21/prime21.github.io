#include <stdio.h>

int ah,am,as;
int bh,bm,bs;

int c,d;

int ans;
int k;

int get_tm(int hh,int mm,int ss){
	return hh * 3600 + mm * 60 + ss;
}

int main(){
	scanf("%d:%d:%d%d:%d:%d%d%d",&ah,&am,&as,&bh,&bm,&bs,&c,&d);
	while ( get_tm( bh,bm,bs)  + d *k <= get_tm(ah,am,as)  +c )
		k++;
	ans = get_tm(bh,bm,bs) + d*k;
	printf("%d:%02d:%02d",ans/60/60,ans/60%60,ans%60);
	return 0;
}
