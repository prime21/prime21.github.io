#include <stdio.h>
#include <string.h>

char str[10101];
int len;
int ret;
int mask[300];

int main(){
	int i;
	while (gets(str)){
		// clear 
		memset(mask,0,sizeof mask);
		ret = 0;

		len = strlen(str);
		for (i=0;i<len;i++)
		if (str[i]>='A' && str[i]<='Z')
			mask[ str[i]-'A' ]=1;
		else if (str[i]>='a' && str[i]<='z')
			mask[ str[i]-'a' ]=1;

		for (i=0;i<26;i++)
			ret += mask[i];

		if (ret==26) {
			printf("OK!\n");
			continue;
		}

		for (i=0;i<26;i++)
		if (mask[i]==0)
			printf("%c ",i+'A');
		printf("\n");

	}
	return 0;
}
