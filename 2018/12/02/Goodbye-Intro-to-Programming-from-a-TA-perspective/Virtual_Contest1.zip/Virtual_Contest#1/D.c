#include <stdio.h>

int main(){
	long long k,n,s,p;
	scanf("%lld%lld%lld%lld",&k,&n,&s,&p);
	printf("%lld", ( k * ((n-1)/s+1) -1 ) / p +1 );
	return 0;
}
